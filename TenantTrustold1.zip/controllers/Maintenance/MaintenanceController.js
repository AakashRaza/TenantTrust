const MaintenanceRequest = require("../../models/MaintenanceRequest");
const Property = require("../../models/PropertyModel");
const MaintenanceReview = require("../../models/MaintenanceReview");

const Review = require("../../models/Review");
const FavouriteProperty = require("../../models/FavouriteProperty");
const BookingRequest = require("../../models/BookingRequest");
const sequelize = require('../../config/db'); // ✅ correct path to your sequelize instance
const { Op, fn, col } = require("sequelize");
const User = require("../../models/User");


// controllers/maintenance.controller.js
exports.createRequest = async (req, res) => {
  try {
    const { propertyId, title, description,requestDate,assignedToId,userId } = req.body;
    const tenantId = req.user?.id;            // set by your auth middleware

    if (!propertyId || !tenantId) {
      return res
        .status(400)
        .json({ success: false, message: 'Missing propertyId or user authentication' });
    }

    const property = await Property.findOne({
      where: { id: propertyId, assignedToId: tenantId },
    });
    if (!property) {
      return res
        .status(403)
        .json({ success: false, message: 'Unauthorized request' });
    }

   
    const images = req.files && req.files.length
      ? req.files.map(f => f.path).join(',')   
      : '';

  
    const request = await MaintenanceRequest.create({
      propertyId,
      assignedToId: tenantId,
      title,
      assignedToId,
      userId ,
      requestDate,
      description,
    //   assignedToId,
      images,          
      status: 'Pending',
    });

  
    return res.status(201).json({
      success: true,
      message: 'Maintenance request created successfully',
      data: {
        ...request.get(),     // everything Sequelize returns
        images,               // make sure caller sees the CSV string
      },
    });
  } catch (error) {
    console.error('Error creating request:', error);
    return res
      .status(500)
      .json({ success: false, message: error.message });
  }
};

exports.getRequestsByStatusAndUserId = async (req, res) => {
  try {
    const { status,propertyId } = req.body;

    const validStatuses = ["Pending", "Active", "Completed"];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid or missing status" });
    }

    // if (!userId) {
    //   return res.status(401).json({ success: false, message: "User ID not found in request" });
    // }
    if (!propertyId) {
      return res.status(401).json({ success: false, message: "property ID not found in request" });
    }

    // Fetch maintenance requests
    const requests = await MaintenanceRequest.findAll({
      where: { status, propertyId },
    });

    // Format requests with images and ratings
    const formattedRequests = await Promise.all(requests.map(async (request) => {
      const raw = request.get();

      let cleanImages = raw.images;
      if (typeof cleanImages === 'string') {
        try {
          cleanImages = JSON.parse(cleanImages);
        } catch {
          // cleanImages = raw.images;
                    cleanImages = raw.cleanImages.split(',').map(img => img.trim());

        }
      }

      let cleanResponceImages = raw.responceImages;
      if (typeof cleanResponceImages === 'string') {
        try {
          cleanResponceImages = JSON.parse(cleanResponceImages);
        } catch {
          cleanResponceImages = raw.responceImages.split(',').map(img => img.trim());
        }
      }

      // Fetch the rating from the MaintenanceReview table
      const review = await MaintenanceReview.findOne({
        where: { maintenanceRequestId: raw.id },
        attributes: ['rating'],
      });

      return {
        ...raw,
        images: cleanImages,
        responceImages: cleanResponceImages,
        rating: review ? review.rating : null,
      };
    }));

    if (formattedRequests.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No maintenance requests found.",
        data: [],
      });
    }

    return res.status(200).json({
      success: true,
      message: "Requests fetched successfully",
      data: formattedRequests,
    });

  } catch (error) {
    console.error("Error fetching requests by userId:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};




exports.getRequestsByStatusAndAssignedToId = async (req, res) => {
  try {
    const { status, assignedToId } = req.body;

    const validStatuses = ["Pending", "Active", "Completed"];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid or missing status" });
    }

    if (!assignedToId) {
      return res.status(400).json({ success: false, message: "Missing assignedToId in request" });
    }

    const requests = await MaintenanceRequest.findAll({
      where: { status, assignedToId },
    });

    const formattedRequests = await Promise.all(requests.map(async (request) => {
      const raw = request.get();

      let cleanImages = raw.images;
      if (typeof cleanImages === 'string') {
        try {
          cleanImages = JSON.parse(cleanImages);
        } catch {
                    cleanImages = raw.cleanImages.split(',').map(img => img.trim());
        }
      }

      let cleanResponceImages = raw.responceImages;
      if (typeof cleanResponceImages === 'string') {
        try {
          cleanResponceImages = JSON.parse(cleanResponceImages);
        } catch {
          cleanResponceImages = raw.responceImages.split(',').map(img => img.trim());
        }
      }

      // Fetch review rating
      const review = await MaintenanceReview.findOne({
        where: { maintenanceRequestId: raw.id },
        attributes: ['rating'],
      });

      return {
        ...raw,
        images: cleanImages,
        responceImages: cleanResponceImages,
        rating: review ? review.rating : null,
      };
    }));

    if (formattedRequests.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No maintenance requests found.",
        data: [],
      });
    }

    return res.status(200).json({
      success: true,
      message: "Requests fetched successfully",
      data: formattedRequests,
    });

  } catch (error) {
    console.error("Error fetching requests by assignedToId:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};




exports.updateRequest = async (req, res) => {
    try {
        const { requestId, title, description,requestDate } = req.body;
        const tenantId = req.user?.id;

        if (!requestId || !tenantId) {
            return res.status(400).json({ success: false, message: "Missing request ID or authentication" });
        }

        const request = await MaintenanceRequest.findOne({
            where: { id: requestId, propertyId: tenantId, status: "Pending" }
        });

        if (!request) {
            return res.status(404).json({ success: false, message: "Request not found or cannot be updated" });
        }

        // New uploaded images, formatted as uploads\filename
        const newImages = req.files && req.files.length
            ? req.files.map(file => `uploads\\${file.filename}`)
            : [];

        // Clean existing images
        let existingImages = [];
        if (request.images && typeof request.images === 'string') {
            // Split by commas and clean up paths
            existingImages = request.images
                .split(',')
                .map(p => p.trim())
                .filter(p => p.match(/^uploads\\[a-zA-Z0-9_-]+\.[a-zA-Z]+$/)) // Strict validation: uploads\filename.ext
                .map(p => p.replace(/^uploads[\\/]+/, 'uploads\\')); // Normalize to uploads\filename
        }

        // Combine and limit to 10
        const updatedImages = [...existingImages, ...newImages].slice(0, 10);

        // Join into CSV string, or set to null if empty
        const imagesString = updatedImages.length > 0 ? updatedImages.join(',') : null;

        // Update request, prevent double-escaping
        await request.update({
            title,
            description,
            requestDate,
            
            images: imagesString
        }, {
            // Ensure raw string is saved without escaping
            silent: true
        });

        // Prepare response
        res.status(200).json({
            success: true,
            message: "Request updated successfully",
            data: {
                ...request.get(),
                images: imagesString
            }
        });

    } catch (error) {
        console.error("Error updating request:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};











exports.respondToRequest = async (req, res) => {
    try {
        const { requestId, responseDescription } = req.body;
    const userId = req.user?.id; // tenant userId from auth middleware

        // Debugging: Log received data
        console.log("Body:", req.body);
        console.log("Files:", req.files);

        // Find the request
        const request = await MaintenanceRequest.findByPk(requestId);
        if (!request) {
            return res.status(404).json({ success: false, message: "Request not found" });
        }
     if (!userId) {
      return res.status(401).json({ success: false, message: "User ID not found in request" });
    }
      const property = await Property.findOne({
      where: { id: request.propertyId, userId },
      attributes: ["id"],
    });
    if (!property) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

        // Authorization: Ensure the user can respond (e.g., tenant or admin)
     

        // Format new response images as uploads\filename
        const newResponseImages = req.files && req.files.length
            ? req.files.map(file => `uploads\\${file.filename}`).join(',')
            : '';

        // Get existing response images (if any) and clean them
        let existingResponseImages = [];
        if (request.responceImages && typeof request.responceImages === 'string') {
            try {
                // Try parsing as JSON (for backward compatibility)
                existingResponseImages = JSON.parse(request.responceImages)
                    .map(p => p.trim())
                    .filter(p => p.match(/^uploads\\[a-zA-Z0-9_-]+\.[a-zA-Z]+$/))
                    .map(p => p.replace(/^uploads[\\/]+/, 'uploads\\'));
            } catch (e) {
                // If not JSON, treat as CSV
                existingResponseImages = request.responceImages
                    .split(',')
                    .map(p => p.trim())
                    .filter(p => p.match(/^uploads\\[a-zA-Z0-9_-]+\.[a-zA-Z]+$/))
                    .map(p => p.replace(/^uploads[\\/]+/, 'uploads\\'));
            }
        }

        // Combine new and existing images, limit to 10
        const updatedResponseImages = [...existingResponseImages, ...(newResponseImages ? newResponseImages.split(',') : [])].slice(0, 10);
        const responseImagesString = updatedResponseImages.length > 0 ? updatedResponseImages.join(',') : null;

        // Update request with response details
        await request.update({
            responceDescription: responseDescription || request.responceDescription,
            responceImages: responseImagesString,
            status: "Active"
        });

        let cleanedImages = '';
if (request.images && typeof request.images === 'string') {
    let raw = request.images;

    // Remove surrounding quotes if present
    if ((raw.startsWith('"') && raw.endsWith('"')) || (raw.startsWith("'") && raw.endsWith("'"))) {
        raw = raw.slice(1, -1);
    }

    // Replace double backslashes with single backslashes
    cleanedImages = raw.replace(/\\\\/g, '\\');
}

        // Prepare response
        res.json({
            success: true,
            message: "Request responded to successfully",
            data: {
                ...request.get(),
                        images: cleanedImages,

                responceImages: responseImagesString
            }
        });

    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ success: false, message: error.message });
    }
};



exports.deleteRequest = async (req, res) => {
    try {
        const { requestId } = req.body;
        const tenantId = req.user?.id;

        if (!requestId || !tenantId) {
            return res.status(400).json({ message: "Missing request ID or authentication" });
        }

        // Find the request
        const request = await MaintenanceRequest.findOne({
            where: { id: requestId, propertyId: tenantId, status: "Pending" }
        });

        if (!request) {
            return res.status(404).json({ message: "Request not found or cannot be deleted" });
        }

        await request.destroy(); // Delete from database

        res.status(200).json({  success:true,message: "Request deleted successfully" });
    } catch (error) {
        console.error("Error deleting request:", error);
        res.status(500).json({  success:false,message: error.message });
    }
};



exports.getLandlordPropertiesWithMaintenanceCountAndDetails = async (req, res) => {
  try {
    const userId = req.user.id;
    const landlordId = req.body.landlordId || userId;

    // Get properties with at least one maintenance request
    const propertiesWithRequests = await Property.findAll({
      where: { userId: landlordId },
      include: [
        {
          model: MaintenanceRequest,
          required: true
        }
      ],
      raw: true,
      nest: true
    });

    if (!propertiesWithRequests.length) {
      return res.status(200).json({
        success: true,
        message: "No properties with maintenance requests found",
        data: []
      });
    }

    const propertyIds = propertiesWithRequests.map(p => p.id);

    const reviews = await Review.findAll({
      attributes: [
        "propertyId",
        [sequelize.fn("AVG", sequelize.col("rating")), "avgRating"]
      ],
      where: {
        propertyId: { [Op.in]: propertyIds }
      },
      group: ["propertyId"],
      raw: true
    });

    const ratingsMap = new Map(reviews.map(r => [r.propertyId, parseFloat(r.avgRating).toFixed(1)]));

    const favouriteProps = await FavouriteProperty.findAll({
      where: { userId },
      attributes: ["propertyId"],
      raw: true
    });

    const favouriteIds = new Set(favouriteProps.map(fav => fav.propertyId));

    const bookingRequests = await BookingRequest.findAll({
      where: { tenantId: userId },
      attributes: ["propertyId"],
      raw: true
    });

    const requestedIds = new Set(bookingRequests.map(req => req.propertyId));

    const formatted = [];

    for (const property of propertiesWithRequests) {
      const images = (() => {
        try {
          if (!property.images) return "";
          const cleaned = property.images.replace(/^"|"$/g, "").replace(/\\"/g, '"');
          const parsed = JSON.parse(cleaned);
          return Array.isArray(parsed)
            ? parsed.map(img => (typeof img === "string" ? img : img.filename)).filter(Boolean).join(", ")
            : "";
        } catch {
          return "";
        }
      })();

      const videoUrl = (() => {
        try {
          if (!property.videoUrl) return null;
          const cleaned = property.videoUrl.replace(/^"|"$/g, "").replace(/\\"/g, '"');
          const parsed = cleaned.startsWith("{") ? JSON.parse(cleaned) : cleaned;
          return typeof parsed === "object" && parsed.filename ? parsed.filename : parsed;
        } catch {
          return null;
        }
      })();

      const amenities = (() => {
        try {
          const raw = property.amenities;
          if (!raw || raw === "") return "";
          let parsed = raw;
          if (typeof raw === "string") {
            try {
              parsed = JSON.parse(raw);
            } catch {
              return raw.split(",").map(item => item.trim()).filter(Boolean).join(", ");
            }
          }
          if (Array.isArray(parsed)) {
            return parsed.map(item => String(item).trim()).filter(Boolean).join(", ");
          }
          return String(parsed);
        } catch {
          return "";
        }
      })();

 const rawRequests = await MaintenanceRequest.findAll({
  where: { propertyId: property.id },
  include: [
    {
      model: User,
      as: 'tenant', // ✅ Must match the defined alias in your model association
      // attributes: ['id', 'name']
    }
  ],
  raw: true,
  nest: true
});




  const maintenanceRequests = await Promise.all(rawRequests.map(async (request) => {
  let cleanImages = request.images;
  if (typeof cleanImages === 'string') {
    try {
      cleanImages = JSON.parse(cleanImages);
    } catch {
      cleanImages = request.images;
    }
  }

  let cleanResponceImages = request.responceImages;
  if (typeof cleanResponceImages === 'string') {
    try {
      cleanResponceImages = JSON.parse(cleanResponceImages);
    } catch {
      cleanResponceImages = request.responceImages.split(',').map(img => img.trim());
    }
  }

  const review = await MaintenanceReview.findOne({
    where: { maintenanceRequestId: request.id },
    attributes: ['rating'],
  });

  return {
    ...request,
    assignedToId: request.assignedToId,
    images: cleanImages,
    responceImages: cleanResponceImages,
    rating: review ? review.rating : null,
  };
}));


      formatted.push({
        id: property.id,
        userId: property.userId,
        title: property.title,
        propertyType: property.propertyType,
        saleOrRent: property.saleOrRent,
        paymentFrequency: property.paymentFrequency,
        amount: property.amount,
        bedrooms: property.bedrooms,
        bathrooms: property.bathrooms,
        startDate: property.startDate,
        endDate: property.endDate,
        rentDeadline: property.rentDeadline,
        location: property.location,
        latitude: property.latitude,
        longitude: property.longitude,
        description: property.description,
        rating: ratingsMap.get(property.id) || null,
        favStatus: favouriteIds.has(property.id),
        requested: requestedIds.has(property.id),
        images,
        videoUrl,
        amenities,
        paymentStatus: "Unpaid",
        createdAt: property.createdAt,
        updatedAt: property.updatedAt,
        maintenanceRequestCount: maintenanceRequests.length,
        maintenanceRequests
      });
    }

    return res.status(200).json({
      success: true,
      message: "Properties with maintenance requests fetched successfully",
      data: formatted
    });

  } catch (error) {
    console.error("Error fetching landlord properties with maintenance details:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};


